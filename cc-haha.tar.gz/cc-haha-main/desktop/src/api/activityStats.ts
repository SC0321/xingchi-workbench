import { api } from './client'

export type ActivityStatsRange = '7d' | '30d' | 'all'

export type DailyActivity = {
  date: string
  messageCount: number
  sessionCount: number
  toolCallCount: number
}

export type DailyModelTokens = {
  date: string
  tokensByModel: Record<string, number>
}

export type StreakInfo = {
  currentStreak: number
  longestStreak: number
  currentStreakStart: string | null
  longestStreakStart: string | null
  longestStreakEnd: string | null
}

export type SessionStats = {
  sessionId: string
  duration: number
  messageCount: number
  timestamp: string
}

export type ModelUsage = {
  inputTokens?: number
  outputTokens?: number
  cacheReadInputTokens?: number
  cacheCreationInputTokens?: number
  webSearchRequests?: number
  /** Estimated dollars. Always 0 for models listed in `unpricedModels`. */
  costUSD?: number
}

export type ActivityStats = {
  totalSessions: number
  totalMessages: number
  totalDays: number
  activeDays: number
  streaks: StreakInfo
  dailyActivity: DailyActivity[]
  dailyModelTokens: DailyModelTokens[]
  longestSession: SessionStats | null
  modelUsage: Record<string, ModelUsage>
  /**
   * Models whose tokens count toward the totals but whose dollars don't, because no published
   * rates exist for them (third-party providers). The cost figure is a floor when this is
   * non-empty, and the UI has to say so rather than presenting it as the whole bill.
   */
  unpricedModels?: string[]
  toolUsage: Record<string, number>
  skillUsage: Record<string, number>
  firstSessionDate: string | null
  lastSessionDate: string | null
  peakActivityDay: string | null
  peakActivityHour: number | null
  totalSpeculationTimeSavedMs: number
}

export type ActivityStatsApiResponse = {
  stats: ActivityStats
  range: ActivityStatsRange
  generatedAt: string
}

export type ActivityStatsResponse = ActivityStats & {
  range: ActivityStatsRange
  generatedAt: string
}

export const activityStatsApi = {
  async getStats(range: ActivityStatsRange = 'all'): Promise<ActivityStatsResponse> {
    const suffix = range === 'all' ? '' : `/${range}`
    const response = await api.get<ActivityStatsApiResponse>(`/api/activity-stats${suffix}`, { timeout: 120_000 })
    return {
      ...response.stats,
      range: response.range,
      generatedAt: response.generatedAt,
    }
  },
}
